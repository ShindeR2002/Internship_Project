# ===== Task 1

# Import necessary libraries
import pandas as pd
import numpy as np
from sklearn.manifold import TSNE

# Read the CSV file into a pandas DataFrame
df = pd.read_csv(r'C:\Users\Rohit\Desktop\New folder\cosmetics.csv')

# Display a sample of five rows of the data
print(df.sample(5))

# Display counts of types of product
product_counts = df['Label'].value_counts()
print(product_counts)




# ======Task 2 
 
# Filter df for "Moisturizer" in the Label column
moisturizers = df[df['Label'] == 'Moisturizer']

# Filter moisturizers for 1 in the Dry column
moisturizers_dry = moisturizers[moisturizers['Dry'] == 1]

# Drop the current index and replace it with a new one
moisturizers_dry = moisturizers_dry.reset_index(drop=True)

# Display the first few rows of the filtered DataFrame
print(moisturizers_dry.head())




# ======Task 3 

# Initialize data structures
corpus = []
ingredient_idx = {}
idx = 0

# Tokenize the ingredients
for ingredients in moisturizers_dry['Ingredients']:  # Replace 'Ingredients' with the actual column name
    # Convert to lowercase and split into tokens
    tokens = ingredients.lower().split(', ')
    
    # Append tokens to the corpus
    corpus.append(tokens)
    
    # Update ingredient dictionary
    for token in tokens:
        if token not in ingredient_idx:
            ingredient_idx[token] = idx
            idx += 1

# Display the corpus and ingredient index dictionary
print("Corpus:", corpus[:5])  # Print the first 5 tokenized ingredient lists for a preview
print("Ingredient Index:", dict(list(ingredient_idx.items())[:10]))  # Print the first 10 ingredients in the dictionary




# ======Task 4 

import numpy as np

# Get the total number of products (M) and ingredients (N)
M = len(moisturizers_dry)
N = len(ingredient_idx)

# Create a matrix of zeros with size MxN
A = np.zeros((M, N))

# Display the shape of the matrix
print("Shape of the Document-Term Matrix:", A.shape)




# ====== Task 5 

import numpy as np

# Define the oh_encoder function
def oh_encoder(ingredients_list, ingredient_idx):
    # Initialize the matrix of zeros with width N
    N = len(ingredient_idx)
    x = np.zeros(N)
    
    # Get index values for each ingredient from ingredient_idx
    for ingredient in ingredients_list:
        if ingredient in ingredient_idx:
            idx = ingredient_idx[ingredient]
            x[idx] = 1  # Set 1 at the corresponding index
            
    return x

# Example usage with a sample ingredients list
sample_ingredients = ['water', 'glycerin', 'sodium hyaluronate']  # Replace with actual ingredient names
encoded_matrix = oh_encoder(sample_ingredients, ingredient_idx)

# Display the encoded matrix
print("One-hot Encoded Matrix:", encoded_matrix)



# ======Task 6

# Initialize the Cosmetic-Ingredient Matrix (A) with zeros
M = len(corpus)  # Number of products
N = len(ingredient_idx)  # Number of ingredients
A = np.zeros((M, N))

# Populate the Cosmetic-Ingredient Matrix
for i, tokens in enumerate(corpus):
    encoded_vector = oh_encoder(tokens, ingredient_idx)
    A[i, :] = encoded_vector  # Set the i-th row of A to the encoded vector
    i += 1  # Increment i by 1 (not necessary for matrix population, but shown for completeness)

# Display the first few rows of the Cosmetic-Ingredient Matrix
print("Cosmetic-Ingredient Matrix (first 5 rows):")
print(A[:5])




# =====Task7 

from sklearn.manifold import TSNE

# Initialize the TSNE model
model = TSNE(n_components=2, learning_rate=200, random_state=42)

# Apply t-SNE to reduce dimensions of the matrix A
tsne_features = model.fit_transform(A)

# Assign the results to the DataFrame
moisturizers_dry['X'] = tsne_features[:, 0]
moisturizers_dry['Y'] = tsne_features[:, 1]

# Display the first few rows of the DataFrame to verify
print(moisturizers_dry[['X', 'Y']].head())



# ====Task8 


from bokeh.plotting import figure, show, output_file
from bokeh.models import ColumnDataSource
import pandas as pd

# Create a ColumnDataSource from the DataFrame
source = ColumnDataSource(moisturizers_dry)

# Create a scatter plot
plot = figure(title="T-SNE Visualization of Cosmetics",
              x_axis_label='T-SNE 1',
              y_axis_label='T-SNE 2')

# Add a scatter renderer to the plot
plot.scatter(x='X', y='Y', source=source, size=8, color="navy", alpha=0.5)

# Output the plot to an HTML file
output_file("tsne_visualization.html")

# Show the plot
show(plot)





# ======Task9 


from bokeh.plotting import figure, show, output_file
from bokeh.models import ColumnDataSource, HoverTool
import pandas as pd
from sklearn.manifold import TSNE

# Load your actual data
df = pd.read_csv(r'C:\Users\Rohit\Desktop\New folder\cosmetics.csv')

# Filter data for 'Moisturizer' and dry skin
moisturizers = df[df['Label'] == 'Moisturizer']
moisturizers_dry = moisturizers[moisturizers['Dry'] == 1].reset_index(drop=True)

# Tokenizing the ingredients
corpus = []
ingredient_idx = {}
idx = 0

for ingredients in moisturizers_dry['Ingredients']:
    tokens = ingredients.lower().split(', ')
    corpus.append(tokens)
    for token in tokens:
        if token not in ingredient_idx:
            ingredient_idx[token] = idx
            idx += 1

# Initialize document-term matrix
M = len(moisturizers_dry)
N = len(ingredient_idx)
A = np.zeros((M, N))

# One-hot encoding function
def oh_encoder(tokens):
    x = np.zeros(N)
    for token in tokens:
        x[ingredient_idx[token]] = 1
    return x

# Fill the document-term matrix
for i, tokens in enumerate(corpus):
    A[i] = oh_encoder(tokens)

# Dimension reduction with t-SNE
model = TSNE(n_components=2, learning_rate=200, random_state=42)
tsne_features = model.fit_transform(A)

# Add t-SNE results to DataFrame
moisturizers_dry['X'] = tsne_features[:, 0]
moisturizers_dry['Y'] = tsne_features[:, 1]

# Assuming moisturizers_dry DataFrame includes columns: 'Name', 'Brand', 'Price', 'Rank'
# Create a ColumnDataSource from the DataFrame
source = ColumnDataSource(moisturizers_dry)

# Create a scatter plot
plot = figure(title="T-SNE Visualization of Cosmetics",
              x_axis_label='T-SNE 1',
              y_axis_label='T-SNE 2')

# Add a scatter renderer to the plot
plot.scatter(x='X', y='Y', source=source, size=8, color="navy", alpha=0.5)

# Create a HoverTool
hover = HoverTool()
hover.tooltips = [
    ('Item', '@Name'),
    ('Brand', '@Brand'),
    ('Price', '$@Price'),
    ('Rank', '@Rank')
]

# Add the HoverTool to the plot
plot.add_tools(hover)

# Output the plot to an HTML file
output_file("tsne_visualization_with_hover.html")



# =====Task10

# Show the plot in a browser
show(plot)



# =====Task11

# Identify the products in the DataFrame by their names
product_1_name = "Color Control Cushion Compact Broad Spectrum SPF 50+"
product_2_name = "BB Cushion Hydra Radiance SPF 50"

# Filter the DataFrame to find these products
product_1 = moisturizers_dry[moisturizers_dry['Name'] == product_1_name]
product_2 = moisturizers_dry[moisturizers_dry['Name'] == product_2_name]

# Check if the products are found
if product_1.empty:
    print(f"Product '{product_1_name}' not found in the dataset.")
else:
    print(f"Product 1: {product_1_name}")
    print("Ingredients:", product_1['Ingredients'].values[0])

if product_2.empty:
    print(f"Product '{product_2_name}' not found in the dataset.")
else:
    print(f"Product 2: {product_2_name}")
    print("Ingredients:", product_2['Ingredients'].values[0])







# Venn Diagram Function
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from matplotlib_venn import venn2
def plot_venn_diagram(df, product_name_1, product_name_2):
    product_col = 'Name'
    ingredient_col = 'Ingredients'
    
    if product_name_1 not in df[product_col].values or product_name_2 not in df[product_col].values:
        print(f"Available product names: {df[product_col].unique()}")
        raise ValueError("The specified product names must exist in the DataFrame.")
    
    product1_ingredients = set(df.loc[df[product_col] == product_name_1, ingredient_col].iloc[0].lower().split(', '))
    product2_ingredients = set(df.loc[df[product_col] == product_name_2, ingredient_col].iloc[0].lower().split(', '))
    
    plt.figure(figsize=(8, 8))
    venn = venn2([product1_ingredients, product2_ingredients], (product_name_1, product_name_2))
    plt.title('Venn Diagram of Product Ingredients')
    plt.show()

# Example usage
plot_venn_diagram(moisturizers_dry, 'Color Control Cushion Compact Broad Spectrum SPF 50+', 'BB Cushion Hydra Radiance SPF 50')



from collections import Counter
# Bar Chart for Ingredient Frequency
# Flatten the list of all ingredients
all_ingredients = [ingredient for sublist in corpus for ingredient in sublist]

# Count the frequency of each ingredient
ingredient_counts = Counter(all_ingredients)

# Get the top 10 most common ingredients
common_ingredients = ingredient_counts.most_common(10)
ingredients, counts = zip(*common_ingredients)

# Create a bar chart
plt.figure(figsize=(10, 6))
plt.bar(ingredients, counts)
plt.xlabel('Ingredients')
plt.ylabel('Counts')
plt.title('Top 10 Most Common Ingredients')
plt.xticks(rotation=45)
plt.show()